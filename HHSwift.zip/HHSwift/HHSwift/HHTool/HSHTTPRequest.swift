//
//  HSHTTPRequest.swift
//  HHSwift
//
//  Created by LXH on 2017/4/17.
//  Copyright © 2017年 HHLM. All rights reserved.
//

import UIKit

class HSHTTPRequest: NSObject {

        
}
