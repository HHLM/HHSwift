//
//  HHUserDefaults.h
//  HHSwift
//
//  Created by LXH on 2017/4/11.
//  Copyright © 2017年 HHLM. All rights reserved.
//

#import <UIKit/UIKit.h>

FOUNDATION_EXPORT double HHUserDefaultsVersionNumber
FOUNDATION_EXPORT const unsigned char HHUserDefaultsVersionString[]
